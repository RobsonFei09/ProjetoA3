drop database Samantha;
CREATE DATABASE Samantha;

USE  Samantha;

CREATE TABLE tb_pessoa (
codigo int auto_increment primary key,
    Nome VARCHAR(50),
    CPF VARCHAR(11),
    Endereco VARCHAR(40),
    Email VARCHAR(40),
    PesoAaltura VARCHAR(15),
    Senha VARCHAR(20),
    Usuario VARCHAR(20) not null
);





select * from tb_pessoa;