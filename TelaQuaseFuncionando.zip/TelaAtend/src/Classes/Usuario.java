/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Classes;
import DAO.ConnectionFactory;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import javax.swing.JOptionPane;


/**
 *
 * @author robso
 */
public class Usuario {
    
    private String Nome;
    private String Email;
    private String Usuario;
    private String Senha;
    private int adm;
    private String SUS;
    private String Endereco;
    private String PesoAltura;
    private String CPF;
    

    public Usuario() {
    }

    public Usuario(String SUS, String Endereco, String PesoAltura, String CPF) {
        this.SUS = SUS;
        this.Endereco = Endereco;
        this.PesoAltura = PesoAltura;
        this.CPF = CPF;
    }

    public String getSUS() {
        return SUS;
    }

    public void setSUS(String SUS) {
        this.SUS = SUS;
    }

    public String getEndereco() {
        return Endereco;
    }

    public void setEndereco(String Endereco) {
        this.Endereco = Endereco;
    }

    public String getPesoAltura() {
        return PesoAltura;
    }

    public void setPesoAltura(String PesoAltura) {
        this.PesoAltura = PesoAltura;
    }

    public String getCPF() {
        return CPF;
    }

    public void setCPF(String CPF) {
        this.CPF = CPF;
    }
    

    public Usuario(String Nome, String Email, String Usuario, String Senha, int adm) {
        this.Nome = Nome;
        this.Email = Email;
        this.Usuario = Usuario;
        this.Senha = Senha;
        this.adm = adm;
    }

    public String getNome() {
        return Nome;
    }

    public void setNome(String Nome) {
        this.Nome = Nome;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    public String getUsuario() {
        return Usuario;
    }

    public void setUsuario(String Usuario) {
        this.Usuario = Usuario;
    }

    public String getSenha() {
        return Senha;
    }

    public void setSenha(String Senha) {
        this.Senha = Senha;
    }

    public int getAdm() {
        return adm;
    }

    public void setAdm(int adm) {
        this.adm = adm;
    }
    
    public void inserir(){
    
    String sql = "INSERT INTO tb_pessoa(Nome, CPF, Endereco, Email , PesoAaltura,Senha,Usuario) VALUES (?, ?, ?, ?, ?, ?,?)";
    ConnectionFactory factory = new ConnectionFactory();
   
    try (Connection c = factory.obtemConexao()){
        PreparedStatement ps = c.prepareStatement(sql);
        ps.setString(1, Nome);
        ps.setString(2, CPF );
        ps.setString(3, Endereco);
        ps.setString(4, Email);
        ps.setString(5,PesoAltura );
        ps.setString(6,Senha );
        ps.setString(7,Usuario );
        ps.execute();
        
        JOptionPane.showMessageDialog(null, "Usuário Incluído com Sucesso!");
    }
    catch (Exception e){
        e.printStackTrace();
    }
    }
    
    
    

    /**
     * @param args the command line arguments
     */
    
    
}
