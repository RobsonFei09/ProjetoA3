/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aula1;

import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 *
 * @author robso
 */
public class Lista1 {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
       
        String nome;
        double salario, totVend,qntComiss, valTot;
        int comiss = 15 ;
        
        System.out.println("Digite o seu nome: ");
        nome = scanner.next();
        System.out.println("Digite o salário: ");
        salario = scanner.nextDouble();
        System.out.println("digite o total de vendas: ");
        totVend = scanner.nextDouble();
        qntComiss = totVend;
        valTot = (salario * 0.15 + salario);
        
        System.out.println("O nome do vendedor é: " + nome);
        System.out.println("O número total de vendas foi de " + totVend + " vendas");
        System.out.println("A comissão do vendedor é de " + comiss + "% sobre as vendas efetuadas");
        System.out.println("O salário fixo do vendedor, é de " + salario + " reais");
        System.out.println("O salário total junto do valor da comissão é de " + valTot + " reais");
        

        
       
    }

}
