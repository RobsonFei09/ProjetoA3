/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.aula1;

import javax.swing.JOptionPane;

/**
 *
 * @author robso
 */
public class Aula1 {

    public static void main(String[] args) {
        /* double valor  = Double.parseDouble( JOptionPane.showInputDialog(
                       "Digite o valor da compra"));
              
       double valorComDesconto = valor * 0.90;
       
       JOptionPane.showMessageDialog(
               null,
               "O valor com desconto é " + valorComDesconto);*/
        /*
        int num1 = Integer.parseInt( JOptionPane.showInputDialog("insira o valor 1"));
        
        int num2 = Integer.parseInt(JOptionPane.showInputDialog("insira o valor 2"));
        
        double media = (num1 + num2) / 2;
        
        JOptionPane.showMessageDialog(null, "A média é " + media); */
       double lado, area;
       lado = Double.parseDouble( JOptionPane.showInputDialog("insira o valor do lado do quadrado"));
        area = lado * lado;
        JOptionPane.showMessageDialog(null, "A area é " + 3 area);
        
        
                
    } 
    
    
}
