CREATE DATABASE Samantha;

USE  Samantha;

CREATE TABLE Cadastro (
id INT auto_increment primary key,
nome VARCHAR (50),
cpf  VARCHAR (11),
endereco VARCHAR (40),
email VARCHAR (40),
carteiraSUS VARCHAR (30),
pesoAltura FLOAT (15)
);

SHOW CREATE TABLE Cadastro;
select * from cadastro;